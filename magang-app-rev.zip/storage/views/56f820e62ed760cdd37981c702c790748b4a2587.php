<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e($judul); ?></title>
    <style>
        table, th, td {
            border: 1px solid black;
            border-collapse: collapse;
            padding: 10px;
        }
    </style>
</head>
<body>

    <h5 style="text-align: center;font-size: 2em"><?php echo e($judul); ?></h5>

    <table border="0" width="100%" cellspacing="0">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Perusahaan</th>
                <th>Posisi</th>
                <th>Deskripsi</th>
                <th>Kuota</th>
                <th>Kuota Terisi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th><?php echo e($loop->iteration); ?></th>
                    <th><?php echo e($v->nama_perusahaan); ?></th>
                    
                    <td><?php echo e($v->posisi); ?></td>
                    <td><?php echo e($v->deskripsi); ?></td>
                    <td><?php echo e($v->kuota); ?></td>
                    <td><?php echo e($v->kuota_terisi); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    
</body>
</html><?php /**PATH C:\xampp\htdocs\magang-app-fix-new\app\views/koordinator-pkl/lowongan/cetak.blade.php ENDPATH**/ ?>