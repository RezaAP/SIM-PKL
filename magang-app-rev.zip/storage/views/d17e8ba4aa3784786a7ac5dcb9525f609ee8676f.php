
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 order-0">
        <div class="card border-0 shadow-sm">
            <div class="d-flex align-items-end row">
                <div class="col-sm-7">
                    <div class="card-body">
                        <h5 class="card-title text-primary mb-0">Selamat Datang, <b><?php echo e(auth()->user()->nama); ?></b></h5>
                        

                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MyServer\www\client-projects\codeigniter\magang-app-rev\app\views/mahasiswa/dashboard.blade.php ENDPATH**/ ?>