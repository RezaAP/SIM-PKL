
<?php $__env->startSection('content'); ?>
<div class="card o-hidden border-0 shadow-lg my-5">
    <div class="card-body p-0">
        <!-- Nested Row within Card Body -->
        <div class="row">
            <div class="col-lg-12 d-flex align-items-center" style="min-height: 680px">
                <div class="p-5 w-100">
                    <div class="text-center">
                        <h1 class="h4 text-gray-900 mb-4">Daftar Sebagai Perusahaan!</h1>
                    </div>
                    <?php echo alert(['success' => 'success','error' => 'danger']); ?>

                    <form class="user" action="" method="post" enctype="multipart/form-data">
                        <div class="row mb-4">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <b>Perusahaan</b>
                                </div>
                                <div class="form-group">
                                    <label for="">Nama Perusahaan</label>
                                    <input type="text" name="nama_perusahaan" class="form-control form-control-user"
                                    placeholder="Nama Perusahaan" value="<?php echo e(old('nama_perusahaan')); ?>">
                                    <?php echo e(error('nama_perusahaan')); ?>

                                </div>
                                <div class="form-group">
                                    <label for="">Deskripsi Perusahaan</label>
                                    <textarea name="deskripsi_perusahaan" rows="2" class="form-control"><?php echo e(old('deskripsi_perusahaan')); ?></textarea>
                                    <?php echo e(error('deskripsi_perusahaan')); ?>

                                </div>
                                <div class="form-group">
                                    <label for="">Tahun Berdiri</label>
                                    <input type="number" name="tahun_berdiri_perusahaan" class="form-control form-control-user"
                                    placeholder="Tahun Berdiri" value="<?php echo e(old('tahun_berdiri_perusahaan')); ?>">
                                    <?php echo e(error('tahun_berdiri_perusahaan')); ?>

                                </div>
                                <div class="form-group">
                                    <label for="">Email</label>
                                    <input type="email" name="email_perusahaan" class="form-control form-control-user"
                                    placeholder="Email Perusahaan" value="<?php echo e(old('email_perusahaan')); ?>">
                                    <?php echo e(error('email_perusahaan')); ?>

                                </div>
                                <div class="form-group">
                                    <label for="">Alamat</label>
                                    <textarea name="alamat_perusahaan" rows="2" class="form-control"><?php echo e(old('alamat_perusahaan')); ?></textarea>
                                    <?php echo e(error('alamat_perusahaan')); ?>

                                </div>
                                <div class="form-group">
                                    <label for="">No Telepon </label>
                                    <input type="text" name="telepon_perusahaan" class="form-control form-control-user" placeholder="No Telepon" value="<?php echo e(old('telepon_perusahaan')); ?>">
                                    <?php echo e(error('telepon_perusahaan')); ?>

                                </div>
                                <div class="form-group">
                                    <b>Dokumen</b>
                                </div>

                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <b>Akun</b>
                                </div>
                                <div class="form-group">
                                    <label for="">Nama Penanggungjawab</label>
                                    <input type="text" name="nama" class="form-control form-control-user"
                                    placeholder="Nama Penanggungjawab" value="<?php echo e(old('nama')); ?>">
                                    <?php echo e(error('nama')); ?>

                                </div>
                                <div class="form-group">
                                    <label for="">Username</label>
                                    <input type="text" name="username" class="form-control form-control-user"
                                    placeholder="Username" value="<?php echo e(old('username')); ?>">
                                    <?php echo e(error('username')); ?>

                                </div>
                                <div class="form-group">
                                    <label for="">Password</label>
                                    <input type="password" name="password" class="form-control form-control-user" placeholder="Password" autocomplete="new-password">
                                    <?php echo e(error('password')); ?>

                                </div>
                                <div class="form-group">
                                    <label for="">Konfirmasi Password</label>
                                    <input type="password" name="konfirmasi_password" class="form-control form-control-user" placeholder="Konfirmasi Password" autocomplete="new-password">
                                    <?php echo e(error('konfirmasi_password')); ?>

                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="">Dokumen KTP</label>
                                            <div class="custom-file">
                                                <input type="file" name="dokumen_ktp" class="custom-file-input" id="dokumen-ktp" accept=".heic,.jpg,.png,.pdf" required>
                                                <label class="custom-file-label" for="dokumen-ktp">Pilih Dokumen</label>
                                            </div>
                                            <?php echo e(error('dokumen_ktp')); ?>

                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="">Dokumen NPWP</label>
                                            <div class="custom-file">
                                                <input type="file" name="dokumen_npwp" class="custom-file-input" id="dokumen-npwp" accept=".heic,.jpg,.png,.pdf" required>
                                                <label class="custom-file-label" for="dokumen-npwp">Pilih Dokumen</label>
                                            </div>
                                            <?php echo e(error('dokumen_npwptp')); ?>

                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="">Dokumen NIB</label>
                                            <div class="custom-file">
                                                <input type="file" name="dokumen_nib" class="custom-file-input" id="dokumen-nib" accept=".heic,.jpg,.png,.pdf" required>
                                                <label class="custom-file-label" for="dokumen-nib">Pilih Dokumen</label>
                                            </div>
                                            <?php echo e(error('dokumen_nib')); ?>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        

                        
                        <button class="btn btn-primary btn-user btn-block">
                            Daftar Sekarang
                        </button>
                    </form>
                    <hr>
                    <div class="text-center">
                        <a class="small" href="<?php echo e(base_url('daftar')); ?>">Sudah mempunyai akun? Masuk</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\magang-app-fix-new\app\views/auth/register.blade.php ENDPATH**/ ?>