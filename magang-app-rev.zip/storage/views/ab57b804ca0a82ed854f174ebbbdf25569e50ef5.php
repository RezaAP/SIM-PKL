
<?php $__env->startSection('content'); ?>
<!-- Page Heading -->
<div class="row mb-3">
    <div class="col-md-6">
        <h1 class="h3 text-gray-800">Bimbingan PKL</h1>
    </div>
    <div class="col-md-6 text-right">
    </div>
</div>

<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Bimbingan</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered content-datatable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Mahasiswa</th>
                        <th>Kegiatan</th>
                        <th>Tanggal Pengajuan</th>
                        
                        <th>Status</th>
                        <th width="350">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th><?php echo e($loop->iteration); ?></th>
                            <td><?php echo e($v->nama_mahasiswa); ?></td>
                            <td><?php echo e($v->catatan_mahasiswa); ?></td>
                            <td><?php echo e(date('d-m-Y H:i',strtotime($v->tanggal_pengajuan))); ?></td>
                            
                            <td>
                                <?php if($v->status == '0'): ?>
                                    <span class="badge badge-warning">Proses Pengajuan</span>
                                <?php elseif($v->status == '1'): ?>
                                    <span class="badge badge-success">Diterima</span>
                                <?php elseif($v->status == '2'): ?>
                                    <span class="badge badge-danger">Ditolak</span>
                                <?php else: ?>
                                    <span class="badge badge-danger">Ditolak</span>
                                <?php endif; ?>
                            </td>
                            <td>

                                <?php if($v->status == '0'): ?>
                                <button class="btn btn-success mr-2" data-toggle="modal" data-target="#ModalTerima<?php echo e($v->id); ?>">Terima</button>
                                <button class="btn btn-danger" data-toggle="modal" data-target="#ModalTolak<?php echo e($v->id); ?>">Tolak</button>
                                <?php endif; ?>

                                <div class="modal fade text-left" id="ModalTolak<?php echo e($v->id); ?>" tabindex="-1" role="dialog"
                                    aria-labelledby="myModalLabel1" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-scrollable" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="myModalLabel1">Konfirmasi</h5>
                                                <button type="button" class="close rounded-pill" data-dismiss="modal"
                                                    aria-label="Close">
                                                    <i data-feather="x"></i>
                                                </button>
                                            </div>
                                            <form action="<?php echo e(base_url('dosen/bimbingan/tolak')); ?>" method="post">
                                                <input type="hidden" name="id" value="<?php echo e($v->id); ?>">
                                                <div class="modal-body">
                                                    <div class="alert alert-warning">Apakah anda yakin ingin menolak pengajuan bimbingan ini?</div>
                                                    
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn" data-dismiss="modal">
                                                        Tutup
                                                    </button>
                                                    <button type="submit" class="btn btn-danger ms-1">
                                                        Tolak
                                                    </button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="modal fade text-left" id="ModalTerima<?php echo e($v->id); ?>" tabindex="-1" role="dialog"
                                    aria-labelledby="myModalLabel1" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-scrollable" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="myModalLabel1">Konfirmasi</h5>
                                                <button type="button" class="close rounded-pill" data-dismiss="modal"
                                                    aria-label="Close">
                                                    <i data-feather="x"></i>
                                                </button>
                                            </div>
                                            <form action="<?php echo e(base_url('dosen/bimbingan/terima')); ?>" method="post">
                                                <input type="hidden" name="id" value="<?php echo e($v->id); ?>">
                                                <div class="modal-body">
                                                    <div class="alert alert-warning">Apakah anda yakin ingin menerima pengajuan bimbingan ini?</div>
                                                    
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn" data-dismiss="modal">
                                                        Tutup
                                                    </button>
                                                    <button type="submit" class="btn btn-success ms-1">
                                                        Terima
                                                    </button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


<div class="modal fade text-left" id="ModalAdd" tabindex="-1" role="dialog"
    aria-labelledby="myModalLabel1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="myModalLabel1">Pengajuan Bimbingan</h5>
                <button type="button" class="close rounded-pill" data-dismiss="modal"
                    aria-label="Close">
                    <i data-feather="x"></i>
                </button>
            </div>
            <form action="<?php echo e(base_url('mahasiswa/bimbingan/store')); ?>" method="post">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="">Nama Pembimbing</label>
                        <h6 class="text-primary"><?php echo e($pembimbing->nama_pembimbing); ?></h6>
                    </div>
                    <div class="form-group">
                        <label for="">Tanggal Pengajuan</label>
                        <input type="datetime-local" name="tanggal_pengajuan" class="form-control" value="<?php echo e(old('tanggal_pengajuan')); ?>">
                        <?php echo e(error('tanggal_pengajuan')); ?>

                    </div>
                    <div class="form-group">
                        <label for="">Kegiatan</label>
                        <textarea name="kegiatan" rows="2" class="form-control" required><?php echo e(old('kegiatan')); ?></textarea>
                        <?php echo e(error('kegiatan')); ?>

                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn" data-dismiss="modal">
                        Batal
                    </button>
                    <button type="submit" class="btn btn-primary ms-1">
                        Ajukan
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MyServer\www\client-projects\codeigniter\magang-app-fix-new\app\views/dosen/bimbingan/index.blade.php ENDPATH**/ ?>