
<?php echo $__env->make('layouts.util.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <div class="container d-flex align-items-center" style="min-height:100vh;">

        <div class="row justify-content-center w-100">

            <div class="col-xl-10 col-lg-12 col-md-9">

                <?php echo $__env->yieldContent('content'); ?>

            </div>

        </div>

    </div>

<?php echo $__env->make('layouts.util.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MyServer\www\client-projects\codeigniter\magang-app\app\views/layouts/auth.blade.php ENDPATH**/ ?>