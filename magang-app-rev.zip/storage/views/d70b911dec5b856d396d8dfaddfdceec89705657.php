<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e($judul); ?></title>
    <style>
        table, th, td {
            border: 1px solid black;
            border-collapse: collapse;
            padding: 10px;
        }
    </style>
</head>
<body>

    <h5 style="text-align: center;font-size: 2em"><?php echo e($judul); ?></h5>

    <table border="0" width="100%" cellspacing="0">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Penanggungjawab</th>
                <th>Nama Perusahaan</th>
                <th>Email Perusahaan</th>
                <th>Tahun Berdiri</th>
                <th>Alamat</th>
                <th>No Telepon</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th><?php echo e($loop->iteration); ?></th>
                    <td><?php echo e($v->penanggungjawab); ?></td>
                    <td><?php echo e($v->nama); ?></td>
                    <td><?php echo e($v->email); ?></td>
                    <td><?php echo e($v->tahun_berdiri); ?></td>
                    <td><?php echo e($v->alamat); ?></td>
                    <td><?php echo e($v->telepon); ?></td>
                    <td>
                        <?php if($v->status == '0'): ?>
                            <span style="padding: 3px 4px;font-size: 11px;color: #fff;background-color: #f6c23e;">Menunggu Diverifikasi</span>
                        <?php elseif($v->status == '1'): ?>
                            <span style="padding: 3px 4px;font-size: 11px;color: #fff;background-color: #1cc88a;">Diverifikasi</span>
                        <?php elseif($v->status == '2'): ?>
                            <span style="padding: 3px 4px;font-size: 11px;color: #fff;background-color: #e74a3b;">Ditolak</span>
                        <?php else: ?>
                            <span style="padding: 3px 4px;font-size: 11px;color: #fff;background-color: #e74a3b;">Ditolak</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    
</body>
</html><?php /**PATH C:\MyServer\www\client-projects\codeigniter\magang-app\app\views/koordinator-pkl/perusahaan/cetak.blade.php ENDPATH**/ ?>