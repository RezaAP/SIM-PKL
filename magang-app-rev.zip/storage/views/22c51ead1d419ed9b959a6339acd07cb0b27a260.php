
<?php $__env->startSection('content'); ?>
<!-- Page Heading -->

<div class="row mb-3">
    <div class="col-md-6">
        <h1 class="h3 text-gray-800">Data Dosen</h1>
    </div>
    <div class="col-md-6 text-right">
        <button class="btn btn-primary" data-toggle="modal" data-target="#ModalAdd">Tambah</button>
    </div>
</div>

<?php echo alert(['success' => 'success','error' => 'danger']); ?>


<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Dosen</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered content-datatable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Username</th>
                        <th>Alamat</th>
                        <th width="150">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th><?php echo e($loop->iteration); ?></th>
                            <td><?php echo e($v->nama); ?></td>
                            <td><?php echo e($v->username); ?></td>
                            <td><?php echo e($v->alamat); ?></td>
                            <td>

                                <button class="btn btn-info" data-toggle="modal" data-target="#ModelEdit<?php echo e($v->id); ?>">Edit</button>
                                <button class="btn btn-danger" data-toggle="modal" data-target="#ModalDelete<?php echo e($v->id); ?>">Hapus</button>

                                <div class="modal fade text-left" id="ModelEdit<?php echo e($v->id); ?>" tabindex="-1" role="dialog"
                                    aria-labelledby="myModalLabel1" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-scrollable" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="myModalLabel1">Edit Data</h5>
                                                <button type="button" class="close rounded-pill" data-dismiss="modal"
                                                    aria-label="Close">
                                                    <i data-feather="x"></i>
                                                </button>
                                            </div>
                                            <form action="<?php echo e(base_url('admin/dosen/update')); ?>" method="post">
                                                <div class="modal-body">
                                                    <input type="hidden" name="id" value="<?php echo e($v->id); ?>">
                                                    <div class="form-group">
                                                        <label for="">Nama</label>
                                                        <input type="text" name="nama" class="form-control" placeholder="Nama" required value="<?php echo e($v->nama); ?>">
                                                        <?php echo e(error('nama')); ?>

                                                    </div>
                                                    <div class="form-group">
                                                        <label for="">Alamat</label>
                                                        <textarea name="alamat" rows="2" class="form-control" placeholder="Alamat" required><?php echo e($v->alamat); ?></textarea>
                                                        <?php echo e(error('alamat')); ?>

                                                    </div>
                                                    <div class="form-group">
                                                        <label for="">Username</label>
                                                        <input type="text" name="username" class="form-control" placeholder="Username" required value="<?php echo e($v->username); ?>">
                                                        <?php echo e(error('username')); ?>

                                                    </div>
                                                    <div class="form-group">
                                                        <label for="">Password <small>(Isi untuk mengubah)</small></label>
                                                        <input type="password" name="password" class="form-control" placeholder="******" autocomplete="new-password">
                                                        <?php echo e(error('password')); ?>

                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn" data-dismiss="modal">
                                                        Batal
                                                    </button>
                                                    <button type="submit" class="btn btn-primary ms-1">
                                                        Simpan
                                                    </button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>

                                <div class="modal fade text-left" id="ModalDelete<?php echo e($v->id); ?>" tabindex="-1" role="dialog"
                                    aria-labelledby="myModalLabel1" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-scrollable" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="myModalLabel1">Konfirmasi</h5>
                                                <button type="button" class="close rounded-pill" data-dismiss="modal"
                                                    aria-label="Close">
                                                    <i data-feather="x"></i>
                                                </button>
                                            </div>
                                            <form action="<?php echo e(base_url('admin/dosen/destroy')); ?>" method="post">
                                                <input type="hidden" name="id" value="<?php echo e($v->id); ?>">
                                                <div class="modal-body">
                                                    <div class="alert alert-warning">Apakah anda yakin ingin menghapus data ini?</div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn" data-dismiss="modal">
                                                        Batal
                                                    </button>
                                                    <button type="submit" class="btn btn-danger ms-1">
                                                        Hapus
                                                    </button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="modal fade text-left" id="ModalAdd" tabindex="-1" role="dialog"
    aria-labelledby="myModalLabel1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="myModalLabel1">Tambah Data</h5>
                <button type="button" class="close rounded-pill" data-dismiss="modal"
                    aria-label="Close">
                    <i data-feather="x"></i>
                </button>
            </div>
            <form action="<?php echo e(base_url('admin/dosen/store')); ?>" method="post">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="">Nama</label>
                        <input type="text" name="nama" class="form-control" placeholder="Nama" required value="<?php echo e(old('nama')); ?>">
                        <?php echo e(error('nama')); ?>

                    </div>
                    <div class="form-group">
                        <label for="">Alamat</label>
                        <textarea name="alamat" rows="2" class="form-control" placeholder="Alamat" required><?php echo e(old('alamat')); ?></textarea>
                        <?php echo e(error('alamat')); ?>

                    </div>
                    <div class="form-group">
                        <label for="">Username</label>
                        <input type="text" name="username" class="form-control" placeholder="Username" required value="<?php echo e(old('username')); ?>">
                        <?php echo e(error('username')); ?>

                    </div>
                    <div class="form-group">
                        <label for="">Password</label>
                        <input type="password" name="password" class="form-control" placeholder="******" autocomplete="new-password" required>
                        <?php echo e(error('password')); ?>

                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn" data-dismiss="modal">
                        Batal
                    </button>
                    <button type="submit" class="btn btn-primary ms-1">
                        Simpan
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<?php echo show_modal(); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MyServer\www\client-projects\codeigniter\magang-app\app\views/admin/dosen/index.blade.php ENDPATH**/ ?>