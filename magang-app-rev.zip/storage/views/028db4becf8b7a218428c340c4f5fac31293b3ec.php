<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e($judul); ?></title>
    <style>
        table, th, td {
            border: 1px solid black;
            border-collapse: collapse;
            padding: 10px;
        }
    </style>
</head>
<body>

    <h5 style="text-align: center;font-size: 2em"><?php echo e($judul); ?></h5>

    <table border="0" width="100%" cellspacing="0">
        <thead>
            <tr>
                <th>No</th>
                <th>Kegiatan</th>
                <th>Jam Absensi</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th><?php echo e($loop->iteration); ?></th>
                    <td><?php echo e($v->kegiatan); ?></td>
                    <td><?php echo e($v->tanggal); ?></td>
                    <td>
                        <?php if($v->status == '0'): ?>
                            <span style="padding: 3px 4px;font-size: 11px;color: #fff;background-color: #f6c23e;">Menunggu Dikonfirmasi</span>
                        <?php elseif($v->status == '1'): ?>
                            <span style="padding: 3px 4px;font-size: 11px;color: #fff;background-color: #1cc88a;">Diterima</span>
                        <?php elseif($v->status == '2'): ?>
                        <span style="padding: 3px 4px;font-size: 11px;color: #fff;background-color: #e74a3b;">Ditolak</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    
</body>
</html><?php /**PATH C:\xampp\htdocs\magang-app-fix-new\app\views/mahasiswa/absensi/cetak.blade.php ENDPATH**/ ?>