<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e($judul); ?></title>
    <style>
        table, th, td {
            border: 1px solid black;
            border-collapse: collapse;
            padding: 10px;
        }
    </style>
</head>
<body>

    <h5 style="text-align: center;font-size: 2em"><?php echo e($judul); ?></h5>

    <table border="0" width="100%" cellspacing="0">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama</th>
                <th>Username</th>
                
                <th>Prodi</th>
                <th>NIM</th>
                <th>Tahun</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th><?php echo e($loop->iteration); ?></th>
                    <td><?php echo e($v->nama_mahasiswa); ?></td>
                    <td><?php echo e($v->username_mahasiswa); ?></td>
                    
                    <td><?php echo e($v->jurusan_mahasiswa); ?></td>
                    <td><?php echo e($v->nim_mahasiswa); ?></td>
                    <td><?php echo e($v->tahun_mahasiswa); ?></td>
                    
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    
</body>
</html><?php /**PATH C:\MyServer\www\client-projects\codeigniter\magang-app-fix-new\app\views/koordinator-pkl/mahasiswa/cetak.blade.php ENDPATH**/ ?>