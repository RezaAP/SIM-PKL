
<?php $__env->startSection('content'); ?>

<div class="row mb-3">
    <div class="col-md-6">
        <h1 class="h3 text-gray-800">Daftar Lowongan</h1>
    </div>
    <div class="col-md-6 text-right">
        
    </div>
</div>


<?php echo alert(['success' => 'success','error' => 'danger']); ?>


<div class="row">
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3">
            <a href="<?php echo e(base_url('mahasiswa/lowongan/show/'.$v->id)); ?>" class="card border-0 shadow text-decoration-none">
                <img src="<?php echo e(thumbnail_lowongan($v->gambar,$v->id)); ?>" alt="" class="card-img-top" width="100%">
                <div class="card-body">
                    <div class="mb-2     h5 font-weight-bold text-dark">
                        <?php echo e($v->posisi); ?>

                    </div>
                    <div class="text-md font-weight-bold text-primary text-uppercase mb-2">
                        <i class="fas fa-building"></i> <?php echo e($v->perusahaan); ?></div>
                    <div class="text-md font-weight-bold text-primary text-uppercase mb-1">
                        <i class="fas fa-users"></i> <?php echo $v->kuota == $v->kuota_terisi? "<span class='text-danger'>Kuota Penuh</span>" : "Kuota $v->kuota_terisi/$v->kuota Orang"; ?>

                    </div>
                </div>
            </a>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MyServer\www\client-projects\codeigniter\magang-app-fix-new\app\views/mahasiswa/lowongan/index.blade.php ENDPATH**/ ?>