
<?php $__env->startSection('content'); ?>
<!-- Page Heading -->



<!-- DataTales Example -->

<?php if($detail): ?>


<div class="row">
    <div class="col-md-4">
        <div class="card shadow">
            <img src="<?php echo e(thumbnail_lowongan($detail->gambar,$detail->id)); ?>" alt="" class="card-img-top" width="100%">
            <div class="card-body">
                <div class="mb-2 h5 font-weight-bold text-dark">
                    <?php echo e($detail->posisi); ?>

                </div>
                <div class="text-md font-weight-bold text-primary text-uppercase mb-2">
                    <i class="fas fa-building"></i> <?php echo e($detail->perusahaan); ?></div>
            </div>
        </div>
    </div>
    <div class="col-md-8">

        <div class="row mb-3">
            <div class="col-md-6">
                <h1 class="h3 text-gray-800"></h1>
            </div>
            <div class="col-md-6 text-right">
                <a href="<?php echo e(base_url('mahasiswa/absensi/cetak')); ?>" target="blank" class="btn btn-danger" id="btn-export">Export PDF</a>
            </div>
        </div>

        <?php echo alert(['success' => 'success','error' => 'danger']); ?>

        

        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <div class="row">
                    <div class="col-md-6">
                        <h6 class="m-0 font-weight-bold text-primary">Absensi PKL</h6>
                    </div>
                    <div class="col-md-6 text-right">
                        <?php if(!$status_absensi): ?>
                        <button class="btn btn-primary" data-toggle="modal" data-target="#ModalAdd">Absen</button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered content-datatable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Kegiatan</th>
                                <th>Jam Absensi</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th><?php echo e($loop->iteration); ?></th>
                                    <td><?php echo e($v->kegiatan); ?></td>
                                    <td><?php echo e($v->tanggal); ?></td>
                                    <td>
                                        <?php if($v->status == '0'): ?>
                                            <span class="badge badge-warning">Menunggu Dikonfirmasi</span>
                                        <?php elseif($v->status == '1'): ?>
                                            <span class="badge badge-success">Diterima</span>
                                        <?php else: ?>
                                            <span class="badge badge-danger">Ditolak</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade text-left" id="ModalAdd" tabindex="-1" role="dialog"
    aria-labelledby="myModalLabel1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="myModalLabel1">Absen</h5>
                <button type="button" class="close rounded-pill" data-dismiss="modal"
                    aria-label="Close">
                    <i data-feather="x"></i>
                </button>
            </div>
            <form action="<?php echo e(base_url('mahasiswa/absensi/store')); ?>" method="post" enctype="multipart/form-data">
                <div class="modal-body">
                    
                    <div class="form-group">
                        <label for="">Kegiatan</label>
                        <textarea name="kegiatan" rows="2" class="form-control" required></textarea>
                        <?php echo e(error('kegiatan')); ?>

                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn" data-dismiss="modal">
                        Batal
                    </button>
                    <button type="submit" class="btn btn-primary ms-1">
                        Absen
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>


<?php else: ?>

<div class="alert alert-warning">
    Anda belum diterima atau belum mendaftar pada salah satu perusahaan yang membuka lowongan. <a href="<?php echo e(base_url('mahasiswa/lowongan')); ?>">Klik disini</a> untuk melakukan pendaftaran
</div>

<?php endif; ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MyServer\www\client-projects\codeigniter\magang-app\app\views/mahasiswa/absensi/index.blade.php ENDPATH**/ ?>