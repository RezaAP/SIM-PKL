
<?php $__env->startSection('content'); ?>
<!-- Page Heading -->

<div class="row mb-3">
    <div class="col-md-6">
        <h1 class="h3 text-gray-800">Penilaian Akhir Mahasiswa</h1>
    </div>
    <div class="col-md-6 text-right">
        
    </div>
</div>

<?php echo alert(['success' => 'success','error' => 'danger']); ?>


<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Mahasiswa PKL</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered content-datatable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Mahasiswa</th>
                        <th>NIM</th>
                        <th>Nama Pembimbing</th>
                        <th>Nama Perusahaan</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th><?php echo e($loop->iteration); ?></th>
                            <td><?php echo e($v->nama_mahasiswa); ?></td>
                            <td><?php echo e($v->nim_mahasiswa); ?></td>
                            <td><?php echo e($v->nama_dosen); ?></td>
                            <td><?php echo e($v->perusahaan); ?></td>
                            <td>
                                <?php if(count($v->laporan_akhir)): ?>
                                <span class="badge badge-success">Sudah Upload</span>
                                <?php else: ?>
                                <span class="badge badge-warning">Belum Upload</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                
                                <?php if(count($v->laporan_akhir)): ?>
                                <button class="btn btn-primary" data-toggle="modal" data-target="#ModalDokumen<?php echo e($v->id); ?>">Lihat Dokumen</button>
                                <?php endif; ?>

                                <div class="modal fade text-left" id="ModalDokumen<?php echo e($v->id); ?>" tabindex="-1" role="dialog"
                                    aria-labelledby="myModalLabel1" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-scrollable modal-lg" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="myModalLabel1">Dokumen</h5>
                                                <button type="button" class="close rounded-pill" data-dismiss="modal"
                                                    aria-label="Close">
                                                    <i data-feather="x"></i>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <?php if(count($v->laporan_akhir)): ?>
                                                <table class="table">
                                                    <?php $__currentLoopData = $v->laporan_akhir; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <th>
                                                            <?php if(get_file_extension($doc->dokumen) != 'pdf'): ?>
                                                                <img src="<?php echo e(base_url($doc->dokumen)); ?>" alt="" width="150">
                                                            <?php else: ?>
                                                                <img src="<?php echo e(base_url('assets/img/pdf.png')); ?>" alt="" width="40"> <?php echo e($doc->nama_dokumen); ?>

                                                            <?php endif; ?>
                                                        </th>
                                                        <td>
                                                            <a href="<?php echo e(base_url($doc->dokumen)); ?>" target="blank" class="btn btn-info mr-2">Lihat</a>
                                                            <a href="<?php echo e(base_url($doc->dokumen)); ?>" download="<?php echo e($doc->nama_dokumen); ?>" class="btn btn-success">Download</a>
                                                        </td>
                                                    </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </table>
                                                <?php endif; ?>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn" data-dismiss="modal">
                                                    Tutup
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MyServer\www\client-projects\codeigniter\magang-app\app\views/koordinator-pkl/mahasiswa/penilaian.blade.php ENDPATH**/ ?>