
<?php $__env->startSection('content'); ?>
<!-- Page Heading -->

<div class="row mb-3">
    <div class="col-md-6">
        <h1 class="h3 text-gray-800">Data Pengajuan PKL</h1>
    </div>
    <div class="col-md-6 text-right">
        
    </div>
</div>

<?php echo alert(['success' => 'success','error' => 'danger']); ?>


<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Pengajuan PKL</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered content-datatable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>NIM</th>
                        <th>Prodi</th>
                        <th>Tahun</th>
                        <th>Posisi</th>
                        <th>Deskripsi</th>
                        <th>Status</th>
                        <th width="300">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th><?php echo e($loop->iteration); ?></th>
                            <td><?php echo e($v->nama_mahasiswa); ?></td>
                            <td><?php echo e($v->nim_mahasiswa); ?></td>
                            <td><?php echo e($v->jurusan_mahasiswa); ?></td>
                            <td><?php echo e($v->tahun_mahasiswa); ?></td>
                            <td><?php echo e($v->posisi); ?></td>
                            <td><?php echo e($v->deskripsi); ?></td>
                            <td>
                                <?php if($v->status == '0'): ?>
                                    <span class="badge badge-warning">Menunggu Dikonfirmasi</span>
                                <?php elseif($v->status == '1'): ?>
                                    <span class="badge badge-success">Diterima</span>
                                <?php else: ?>
                                    <span class="badge badge-danger">Ditolak</span>
                                <?php endif; ?>
                            </td>
                            <td>

                                <button class="btn btn-info" data-toggle="modal" data-target="#ModalDokumen<?php echo e($v->id); ?>">Lihat Dokumen</button>
                                <?php if($v->status == '0'): ?>
                                <button class="btn btn-success" data-toggle="modal" data-target="#ModalVerifikasi<?php echo e($v->id); ?>">Terima</button>
                                <button class="btn btn-danger" data-toggle="modal" data-target="#ModalTolak<?php echo e($v->id); ?>">Tolak</button>
                                <?php endif; ?>

                                <div class="modal fade text-left" id="ModalVerifikasi<?php echo e($v->id); ?>" tabindex="-1" role="dialog"
                                    aria-labelledby="myModalLabel1" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-scrollable" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="myModalLabel1">Konfirmasi</h5>
                                                <button type="button" class="close rounded-pill" data-dismiss="modal"
                                                    aria-label="Close">
                                                    <i data-feather="x"></i>
                                                </button>
                                            </div>
                                            <form action="<?php echo e(base_url('perusahaan/pengajuan/terima')); ?>" method="post">
                                                <input type="hidden" name="id" value="<?php echo e($v->id); ?>">
                                                <div class="modal-body">
                                                    <div class="alert alert-warning">Apakah anda yakin ingin menerima pengajuan ini?</div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn" data-dismiss="modal">
                                                        Batal
                                                    </button>
                                                    <button type="submit" class="btn btn-success ms-1">
                                                        Terima
                                                    </button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal fade text-left" id="ModalTolak<?php echo e($v->id); ?>" tabindex="-1" role="dialog"
                                    aria-labelledby="myModalLabel1" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-scrollable" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="myModalLabel1">Konfirmasi</h5>
                                                <button type="button" class="close rounded-pill" data-dismiss="modal"
                                                    aria-label="Close">
                                                    <i data-feather="x"></i>
                                                </button>
                                            </div>
                                            <form action="<?php echo e(base_url('perusahaan/pengajuan/tolak')); ?>" method="post">
                                                <input type="hidden" name="id" value="<?php echo e($v->id); ?>">
                                                <div class="modal-body">
                                                    <div class="alert alert-warning">Apakah anda yakin ingin menolak pengajuan ini?</div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn" data-dismiss="modal">
                                                        Batal
                                                    </button>
                                                    <button type="submit" class="btn btn-danger ms-1">
                                                        Tolak
                                                    </button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal fade text-left" id="ModalDokumen<?php echo e($v->id); ?>" tabindex="-1" role="dialog"
                                    aria-labelledby="myModalLabel1" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-scrollable modal-lg" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="myModalLabel1">Dokumen</h5>
                                                <button type="button" class="close rounded-pill" data-dismiss="modal"
                                                    aria-label="Close">
                                                    <i data-feather="x"></i>
                                                </button>
                                            </div>
                                            <form action="<?php echo e(base_url('perusahaan/pengajuan/tolak')); ?>" method="post">
                                                <input type="hidden" name="id" value="<?php echo e($v->id); ?>">
                                                <div class="modal-body">
                                                    <?php if(count($v->dokumen)): ?>
                                                        <ul>
                                                            <?php $__currentLoopData = $v->dokumen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <li class="mb-3">
                                                                    <a href="<?php echo e(base_url($doc->dokumen)); ?>" target="blank">
                                                                        <?php if(get_file_extension($doc->dokumen) != 'pdf'): ?>
                                                                            <img src="<?php echo e(base_url($doc->dokumen)); ?>" alt="" width="150">
                                                                        <?php else: ?>
                                                                            <img src="<?php echo e(base_url('assets/img/pdf.png')); ?>" alt="" width="40"> <?php echo e($doc->nama_dokumen); ?>

                                                                        <?php endif; ?>
                                                                    </a>
                                                                </li>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </ul>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn" data-dismiss="modal">
                                                        Tutup
                                                    </button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MyServer\www\client-projects\codeigniter\magang-app-fix-new\app\views/perusahaan/pengajuan/index.blade.php ENDPATH**/ ?>