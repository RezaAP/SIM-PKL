
<?php $__env->startSection('content'); ?>
<div class="card o-hidden border-0 shadow-lg my-5">
    <div class="card-body p-0">
        <!-- Nested Row within Card Body -->
        <div class="row">
            <div class="col-lg-6 d-none d-lg-block bg-login-image"></div>
            <div class="col-lg-6 d-flex align-items-center" style="min-height: 680px">
                <div class="p-5 w-100">
                    <div class="text-center">
                        <h1 class="h4 text-gray-900 mb-4">Selamat Datang!</h1>
                    </div>
                    <?php echo alert(['success' => 'success','error' => 'danger']); ?>

                    <form class="user" action="" method="post">
                        <div class="form-group">
                            <label for="">Username</label>
                            <input type="text" name="username" class="form-control form-control-user"
                            placeholder="Username">
                            <?php echo e(error('username')); ?>

                        </div>
                        <div class="form-group">
                            <label for="">Password</label>
                            <input type="password" name="password" class="form-control form-control-user" placeholder="Password">
                            <?php echo e(error('password')); ?>

                        </div>
                        <button class="btn btn-primary btn-user btn-block">
                            Login
                        </button>
                    </form>
                    <hr>
                    <div class="text-center">
                        <a class="small" href="<?php echo e(base_url('daftar')); ?>">Daftar Perusahaan!</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MyServer\www\client-projects\codeigniter\magang-app-fix-new\app\views/auth/login.blade.php ENDPATH**/ ?>