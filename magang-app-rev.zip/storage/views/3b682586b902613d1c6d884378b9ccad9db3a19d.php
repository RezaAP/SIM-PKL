<li class="nav-item<?php echo e(segment(2) == ''? ' active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(base_url('dosen')); ?>">
        <i class="fas fa-fw fa-tachometer-alt"></i>
        <span>Beranda</span></a>
</li>
<li class="nav-item<?php echo e(segment(2) == 'mahasiswa'? ' active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(base_url('dosen/mahasiswa')); ?>">
        <i class="fas fa-fw fa-user-friends"></i>
        <span>Data Mahasiswa</span></a>
</li>
<li class="nav-item<?php echo e(segment(2) == 'bimbingan'? ' active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(base_url('dosen/bimbingan')); ?>">
        <i class="fas fa-fw fa-business-time"></i>
        <span>Bimbingan</span></a>
</li>
<?php /**PATH C:\xampp\htdocs\magang-app-fix-new\app\views/layouts/util/dosen-sidebar.blade.php ENDPATH**/ ?>