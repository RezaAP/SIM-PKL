
<?php $__env->startSection('content'); ?>
<!-- Page Heading -->

<div class="row mb-3">
    <div class="col-md-6">
        <h1 class="h3 text-gray-800">Data Lowongan</h1>
    </div>
    <div class="col-md-6 text-right">
        <button class="btn btn-primary" data-toggle="modal" data-target="#ModalAdd">Tambah</button>
    </div>
</div>

<?php echo alert(['success' => 'success','error' => 'danger']); ?>


<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Lowongan</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered content-datatable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Gambar</th>
                        <th>Posisi</th>
                        <th>Deskripsi</th>
                        <th>Dokumen yang dibutuhkan</th>
                        <th>Kuota</th>
                        <th>Kuota Terisi</th>
                        <th width="150">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th><?php echo e($loop->iteration); ?></th>
                            <td><img src="<?php echo e(thumbnail_lowongan($v->gambar,$i)); ?>" alt="" width="100"></td>
                            <td><?php echo e($v->posisi); ?></td>
                            <td><?php echo e($v->deskripsi); ?></td>
                            <td><?php echo e($v->deskripsi_dokumen); ?></td>
                            <td><?php echo e($v->kuota); ?></td>
                            <td><?php echo e($v->kuota_terisi); ?></td>
                            <td>

                                <button class="btn btn-info" data-toggle="modal" data-target="#ModelEdit<?php echo e($v->id); ?>">Edit</button>
                                <?php if($v->kuota_terisi == 0): ?>
                                <button class="btn btn-danger" data-toggle="modal" data-target="#ModalDelete<?php echo e($v->id); ?>">Hapus</button>
                                <?php endif; ?>

                                <div class="modal fade text-left" id="ModelEdit<?php echo e($v->id); ?>" tabindex="-1" role="dialog"
                                    aria-labelledby="myModalLabel1" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-scrollable" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="myModalLabel1">Edit Data</h5>
                                                <button type="button" class="close rounded-pill" data-dismiss="modal"
                                                    aria-label="Close">
                                                    <i data-feather="x"></i>
                                                </button>
                                            </div>
                                            <form action="<?php echo e(base_url('perusahaan/lowongan/update')); ?>" method="post" enctype="multipart/form-data">
                                                <div class="modal-body">
                                                    <input type="hidden" name="id" value="<?php echo e($v->id); ?>">
                                                    <div class="form-group">
                                                        <label for="">Gambar / Thumbnail <small>(Pilih gambar untuk mengubah gambar sebelumnya)</small></label>
                                                        <div class="custom-file">
                                                            <input type="file" name="gambar" class="custom-file-input" id="dokumen-ktp" accept=".heic,.jpg,.png">
                                                            <label class="custom-file-label" for="dokumen-ktp">Pilih Gambar</label>
                                                        </div>
                                                        <?php echo e(error('gambar')); ?>

                                                    </div>
                                                    <div class="form-group">
                                                        <label for="">Posisi</label>
                                                        <input type="text" name="posisi" class="form-control" placeholder="Posisi" required value="<?php echo e($v->posisi); ?>">
                                                        <?php echo e(error('posisi')); ?>

                                                    </div>
                                                    <div class="form-group">
                                                        <label for="">Deskripsi</label>
                                                        <textarea name="deskripsi" rows="2" class="form-control" placeholder="Deskripsi" required><?php echo e($v->deskripsi); ?></textarea>
                                                        <?php echo e(error('deskripsi')); ?>

                                                    </div>
                                                    <div class="form-group">
                                                        <label for="">Kuota</label>
                                                        <input type="number" name="kuota" class="form-control" placeholder="Kuota" required value="<?php echo e($v->kuota); ?>">
                                                        <?php echo e(error('kuota')); ?>

                                                    </div>
                                                    <div class="form-group">
                                                        <label for="">Dokumen yang dibutuhkan</label>
                                                        <textarea name="deskripsi_dokumen" rows="2" class="form-control" placeholder="- Dokumen 1 .dst" required><?php echo e($v->deskripsi_dokumen); ?></textarea>
                                                        <?php echo e(error('deskripsi_dokumen')); ?>

                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn" data-dismiss="modal">
                                                        Batal
                                                    </button>
                                                    <button type="submit" class="btn btn-primary ms-1">
                                                        Simpan
                                                    </button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>

                                <div class="modal fade text-left" id="ModalDelete<?php echo e($v->id); ?>" tabindex="-1" role="dialog"
                                    aria-labelledby="myModalLabel1" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-scrollable" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="myModalLabel1">Konfirmasi</h5>
                                                <button type="button" class="close rounded-pill" data-dismiss="modal"
                                                    aria-label="Close">
                                                    <i data-feather="x"></i>
                                                </button>
                                            </div>
                                            <form action="<?php echo e(base_url('perusahaan/lowongan/destroy')); ?>" method="post">
                                                <input type="hidden" name="id" value="<?php echo e($v->id); ?>">
                                                <div class="modal-body">
                                                    <div class="alert alert-warning">Apakah anda yakin ingin menghapus data ini?</div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn" data-dismiss="modal">
                                                        Batal
                                                    </button>
                                                    <button type="submit" class="btn btn-danger ms-1">
                                                        Hapus
                                                    </button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="modal fade text-left" id="ModalAdd" tabindex="-1" role="dialog"
    aria-labelledby="myModalLabel1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="myModalLabel1">Tambah Data</h5>
                <button type="button" class="close rounded-pill" data-dismiss="modal"
                    aria-label="Close">
                    <i data-feather="x"></i>
                </button>
            </div>
            <form action="<?php echo e(base_url('perusahaan/lowongan/store')); ?>" method="post" enctype="multipart/form-data">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="">Gambar / Thumbnail</label>
                        <div class="custom-file">
                            <input type="file" name="gambar" class="custom-file-input" id="dokumen-ktp" accept=".heic,.jpg,.png">
                            <label class="custom-file-label" for="dokumen-ktp">Pilih Gambar</label>
                        </div>
                        <?php echo e(error('gambar')); ?>

                    </div>
                    <div class="form-group">
                        <label for="">Posisi</label>
                        <input type="text" name="posisi" class="form-control" placeholder="Posisi" required value="<?php echo e(old('posisi')); ?>">
                        <?php echo e(error('posisi')); ?>

                    </div>
                    <div class="form-group">
                        <label for="">Deskripsi</label>
                        <textarea name="deskripsi" rows="2" class="form-control" placeholder="Deskripsi" required><?php echo e(old('deskripsi')); ?></textarea>
                        <?php echo e(error('deskripsi')); ?>

                    </div>
                    <div class="form-group">
                        <label for="">Kuota</label>
                        <input type="number" name="kuota" class="form-control" placeholder="Kuota" required value="<?php echo e(old('kuota')); ?>">
                        <?php echo e(error('kuota')); ?>

                    </div>
                    <div class="form-group">
                        <label for="">Dokumen yang dibutuhkan</label>
                        <textarea name="deskripsi_dokumen" rows="2" class="form-control" placeholder="- Dokumen 1 .dst" required><?php echo e(old('deskripsi_dokumen')); ?></textarea>
                        <?php echo e(error('deskripsi_dokumen')); ?>

                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn" data-dismiss="modal">
                        Batal
                    </button>
                    <button type="submit" class="btn btn-primary ms-1">
                        Simpan
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<?php echo show_modal(); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MyServer\www\client-projects\codeigniter\magang-app\app\views/perusahaan/lowongan/index.blade.php ENDPATH**/ ?>