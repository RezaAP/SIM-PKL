
<?php $__env->startSection('content'); ?>
<!-- Page Heading -->
<div class="row mb-3">
    <div class="col-md-6">
        <h1 class="h3 text-gray-800">Data Perusahaan</h1>
    </div>
    <div class="col-md-6 text-right">
        <a href="<?php echo e(base_url('koordinator-pkl/cetak/perusahaan')); ?>" target="blank" class="btn btn-danger" id="btn-export">Export PDF</a>
    </div>
</div>

<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <div class="row">
            <div class="col-md-6">
                <h6 class="m-0 font-weight-bold text-primary">Perusahaan</h6>
            </div>
            <div class="col-3 ml-auto d-flex align-items-center">
                <span class="mr-2">Filter: </span>
                <select name="status" id="" class="form-control">
                    <option value="">Semua</option>
                    <option value="0">Menunggu Diverifikasi</option>
                    <option value="1">Diverifikasi</option>
                    <option value="2">Ditolak</option>
                </select>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered content-datatable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Penanggungjawab</th>
                        <th>Nama Perusahaan</th>
                        <th>Email Perusahaan</th>
                        <th>Tahun Berdiri</th>
                        <th>Alamat</th>
                        <th>No Telepon</th>
                        <th>Status</th>
                        <th width="350">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th><?php echo e($loop->iteration); ?></th>
                            <td><?php echo e($v->penanggungjawab); ?></td>
                            <td><?php echo e($v->nama); ?></td>
                            <td><?php echo e($v->email); ?></td>
                            <td><?php echo e($v->tahun_berdiri); ?></td>
                            <td><?php echo e($v->alamat); ?></td>
                            <td><?php echo e($v->telepon); ?></td>
                            <td>
                                <?php if($v->status == '0'): ?>
                                    <span class="badge badge-warning">Menunggu Diverifikasi</span>
                                <?php elseif($v->status == '1'): ?>
                                    <span class="badge badge-success">Diverifikasi</span>
                                <?php elseif($v->status == '2'): ?>
                                    <span class="badge badge-danger">Ditolak</span>
                                <?php else: ?>
                                    <span class="badge badge-danger">Ditolak</span>
                                <?php endif; ?>
                            </td>
                            <td>

                                <button class="btn btn-info" data-toggle="modal" data-target="#ModalDokumen<?php echo e($v->id); ?>">Detail Dokumen</button>
                                <?php if($v->status == '0'): ?>
                                <button class="btn btn-success" data-toggle="modal" data-target="#ModalVerifikasi<?php echo e($v->id); ?>">Verifikasi</button>
                                <button class="btn btn-danger" data-toggle="modal" data-target="#ModalTolak<?php echo e($v->id); ?>">Tolak</button>
                                <?php elseif($v->status == '1'): ?>
                                
                                
                                <?php endif; ?>

                                <div class="modal fade text-left" id="ModalDokumen<?php echo e($v->id); ?>" tabindex="-1" role="dialog"
                                    aria-labelledby="myModalLabel1" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-scrollable modal-lg" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="myModalLabel1">Dokumen</h5>
                                                <button type="button" class="close rounded-pill" data-dismiss="modal"
                                                    aria-label="Close">
                                                    <i data-feather="x"></i>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <table class="table table-light">
                                                    <tr>
                                                        <th width="200">Dokumen KTP</th>
                                                        <td> :
                                                            <a href="<?php echo e(base_url($v->dokumen_ktp)); ?>" target="blank">
                                                                <?php if(get_file_extension($v->dokumen_ktp) != 'pdf'): ?>
                                                                    <img src="<?php echo e(base_url($v->dokumen_ktp)); ?>" alt="" width="150">
                                                                <?php else: ?>
                                                                    <img src="<?php echo e(base_url('assets/img/pdf.png')); ?>" alt="" width="40"> dokumen.pdf
                                                                <?php endif; ?>
                                                            </a>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th width="200">Dokumen NPWP</th>
                                                        <td> :
                                                            <a href="<?php echo e(base_url($v->dokumen_npwp)); ?>" target="blank">
                                                                <?php if(get_file_extension($v->dokumen_npwp) != 'pdf'): ?>
                                                                    <img src="<?php echo e(base_url($v->dokumen_npwp)); ?>" alt="" width="150">
                                                                <?php else: ?>
                                                                    <img src="<?php echo e(base_url('assets/img/pdf.png')); ?>" alt="" width="40"> dokumen.pdf
                                                                <?php endif; ?>
                                                            </a>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th width="200">Dokumen NIB</th>
                                                        <td> :
                                                            <a href="<?php echo e(base_url($v->dokumen_nib)); ?>" target="blank">
                                                                <?php if(get_file_extension($v->dokumen_nib) != 'pdf'): ?>
                                                                    <img src="<?php echo e(base_url($v->dokumen_nib)); ?>" alt="" width="150">
                                                                <?php else: ?>
                                                                    <img src="<?php echo e(base_url('assets/img/pdf.png')); ?>" alt="" width="40"> dokumen.pdf
                                                                <?php endif; ?>
                                                            </a>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn" data-dismiss="modal">
                                                    Tutup
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal fade text-left" id="ModalVerifikasi<?php echo e($v->id); ?>" tabindex="-1" role="dialog"
                                    aria-labelledby="myModalLabel1" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-scrollable" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="myModalLabel1">Konfirmasi</h5>
                                                <button type="button" class="close rounded-pill" data-dismiss="modal"
                                                    aria-label="Close">
                                                    <i data-feather="x"></i>
                                                </button>
                                            </div>
                                            <form action="<?php echo e(base_url('koordinator-pkl/perusahaan/verifikasi')); ?>" method="post">
                                                <input type="hidden" name="id" value="<?php echo e($v->id); ?>">
                                                <div class="modal-body">
                                                    <div class="alert alert-warning">Apakah anda yakin ingin memverifikasi data ini?</div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn" data-dismiss="modal">
                                                        Batal
                                                    </button>
                                                    <button type="submit" class="btn btn-success ms-1">
                                                        Verifikasi
                                                    </button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal fade text-left" id="ModalTolak<?php echo e($v->id); ?>" tabindex="-1" role="dialog"
                                    aria-labelledby="myModalLabel1" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-scrollable" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="myModalLabel1">Konfirmasi</h5>
                                                <button type="button" class="close rounded-pill" data-dismiss="modal"
                                                    aria-label="Close">
                                                    <i data-feather="x"></i>
                                                </button>
                                            </div>
                                            <form action="<?php echo e(base_url('koordinator-pkl/perusahaan/tolak')); ?>" method="post">
                                                <input type="hidden" name="id" value="<?php echo e($v->id); ?>">
                                                <div class="modal-body">
                                                    <div class="alert alert-warning">Apakah anda yakin ingin menolak verifikasi data ini?</div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn" data-dismiss="modal">
                                                        Batal
                                                    </button>
                                                    <button type="submit" class="btn btn-danger ms-1">
                                                        Tolak
                                                    </button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal fade text-left" id="ModalBatalVerifikasi<?php echo e($v->id); ?>" tabindex="-1" role="dialog"
                                    aria-labelledby="myModalLabel1" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-scrollable" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="myModalLabel1">Konfirmasi</h5>
                                                <button type="button" class="close rounded-pill" data-dismiss="modal"
                                                    aria-label="Close">
                                                    <i data-feather="x"></i>
                                                </button>
                                            </div>
                                            <form action="<?php echo e(base_url('koordinator-pkl/perusahaan/batal_verifikasi')); ?>" method="post">
                                                <input type="hidden" name="id" value="<?php echo e($v->id); ?>">
                                                <div class="modal-body">
                                                    <div class="alert alert-warning">Apakah anda yakin ingin membatalkan verifikasi data ini?</div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn" data-dismiss="modal">
                                                        Batal
                                                    </button>
                                                    <button type="submit" class="btn btn-danger ms-1">
                                                        Batalkan
                                                    </button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>

                                <div class="modal fade text-left" id="ModalEdit<?php echo e($v->id); ?>" tabindex="-1" role="dialog"
                                    aria-labelledby="myModalLabel1" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-scrollable" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="myModalLabel1">Edit Data</h5>
                                                <button type="button" class="close rounded-pill" data-dismiss="modal"
                                                    aria-label="Close">
                                                    <i data-feather="x"></i>
                                                </button>
                                            </div>
                                            <form action="<?php echo e(base_url('koordinator-pkl/perusahaan/update')); ?>" method="post">
                                                <div class="modal-body">
                                                    <input type="hidden" name="id" value="<?php echo e($v->id); ?>">
                                                    <div class="form-group">
                                                        <label for="">Nama Penanggungjawab</label>
                                                        <input type="text" name="nama_penanggungjawab" class="form-control" placeholder="Nama Penanggungjawab" value="<?php echo e($v->penanggungjawab); ?>">
                                                        <?php echo e(error('nama_penanggungjawab')); ?>

                                                    </div>
                                                    <div class="form-group">
                                                        <label for="">No. Telepon</label>
                                                        <input type="text" name="telepon" class="form-control" placeholder="No. Telepon" value="<?php echo e($v->telepon); ?>">
                                                        <?php echo e(error('telepon')); ?>

                                                    </div>
                                                    <div class="form-group">
                                                        <label for="">Email</label>
                                                        <input type="email" name="email" class="form-control" placeholder="Email" value="<?php echo e($v->email); ?>">
                                                        <?php echo e(error('email')); ?>

                                                    </div>
                                                    <div class="form-group">
                                                        <label for="">Username</label>
                                                        <input type="text" name="username" class="form-control" placeholder="Username" value="<?php echo e($v->penanggungjawab_username); ?>">
                                                        <?php echo e(error('username')); ?>

                                                    </div>
                                                    <div class="form-group">
                                                        <label for="">Password (opsional)</label>
                                                        <input type="password" name="password" class="form-control" placeholder="password" value="">
                                                        <?php echo e(error('password')); ?>

                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn" data-dismiss="modal">
                                                        Batal
                                                    </button>
                                                    <button type="submit" class="btn btn-primary ms-1">
                                                        Simpan
                                                    </button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MyServer\www\client-projects\codeigniter\magang-app-fix-new\app\views/koordinator-pkl/perusahaan/index.blade.php ENDPATH**/ ?>