
<?php $__env->startSection('content'); ?>

<div class="row mb-3">
    <div class="col-md-6">
        <h1 class="h3 text-gray-800">Detail Lowongan</h1>
    </div>
    <div class="col-md-6 text-right">
        
    </div>
</div>

<?php echo alert(['success' => 'success','error' => 'danger']); ?>


<div class="row">
    <div class="col-md-6 offset-md-3">
        <div class="card shadow h-100">
            <img src="<?php echo e(thumbnail_lowongan($data->gambar,$data->id)); ?>" width="100%" class="card-img-top">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($data->perusahaan); ?> - <?php echo e($data->posisi); ?></div>
                        <hr>
                        <div class="row">
                            <div class="col md-4">
                                <div class="text-md font-weight-bold text-dark text-uppercase mb-1">
                                    Kuota
                                </div>
                                <div class="text-md text-dark text-uppercase mb-1">
                                    <i class="fas fa-users"></i> <?php echo $data->kuota == $data->kuota_terisi? "<span class='text-danger'>Kuota Penuh</span>" : " $data->kuota_terisi/$data->kuota Orang"; ?>

                                </div>
                            </div>
                        </div>
                        <hr>
                        <div class="text-md font-weight-bold text-dark text-uppercase mb-1">
                            Deskripsi
                        </div>
                        <div class="text-md text-dark">
                            <?php echo e($data->deskripsi); ?>                            
                        </div>
                        <hr>
                        <?php if($data->kuota != $data->kuota_terisi): ?>
                            <?php if($data->status_pengajuan == '0'): ?>
                            <a data-toggle="modal" data-target="#ModalDaftar" class="btn btn-primary w-100">
                                Daftar
                            </a>
                            <?php else: ?>
                                <button class="btn btn-light border w-100 disabled" disabled>Sudah Mendaftar</button>
                            <?php endif; ?>
                        <?php else: ?>
                        <div class="alert alert-warning">Mohon Maaf Kuota Sudah Penuh</div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade text-left" id="ModalDaftar" tabindex="-1" role="dialog"
    aria-labelledby="myModalLabel1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="myModalLabel1">Dokumen Pengajuan</h5>
                <button type="button" class="close rounded-pill" data-dismiss="modal"
                    aria-label="Close">
                    <i data-feather="x"></i>
                </button>
            </div>
            <form action="<?php echo e(base_url('mahasiswa/lowongan/daftar')); ?>" method="post" enctype="multipart/form-data">
                <div class="modal-body">
                    <input type="hidden" name="id" value="<?php echo e($data->id); ?>">
                    
                    <div class="alert alert-warning">
                        Apakah anda yakin ingin mendaftar pada perusahaan <?php echo e($data->perusahaan); ?>?
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn" data-dismiss="modal">
                        Batal
                    </button>
                    <button type="submit" class="btn btn-primary ms-1">
                        Daftar
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\magang-app-fix-new\app\views/mahasiswa/lowongan/show.blade.php ENDPATH**/ ?>