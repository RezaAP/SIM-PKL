
<?php $__env->startSection('content'); ?>
<!-- Page Heading -->

<div class="row mb-3">
    <div class="col-md-6">
        <h1 class="h3 text-gray-800">Pendaftaran Mahasiswa</h1>
    </div>
    <div class="col-md-6 text-right">
        
        
    </div>
</div>

<?php echo alert(['success' => 'success','error' => 'danger']); ?>


<div class="card shadow">
    <div class="card-body">
        <button class="btn btn-primary mr-2" data-toggle="modal" data-target="#ModalAdd">Tambah</button>
        <button class="btn btn-success mr-2" data-toggle="modal" data-target="#ModalImport">Import</button>
    </div>
</div>

<div class="modal fade text-left" id="ModalAdd" tabindex="-1" role="dialog"
    aria-labelledby="myModalLabel1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="myModalLabel1">Tambah Data</h5>
                <button type="button" class="close rounded-pill" data-dismiss="modal"
                    aria-label="Close">
                    <i data-feather="x"></i>
                </button>
            </div>
            <form action="<?php echo e(base_url('koordinator-pkl/mahasiswa/store')); ?>" method="post">
                <div class="modal-body">
                    
                    <div class="form-group">
                        <label for="">Nama</label>
                        <input type="text" name="nama" class="form-control" placeholder="Nama" required value="<?php echo e(old('nama')); ?>">
                        <?php echo e(error('nama')); ?>

                    </div>
                    <div class="form-group">
                        <label for="">NIM</label>
                        <input type="text" name="nim" class="form-control" placeholder="NIM" required value="<?php echo e(old('nim')); ?>">
                        <?php echo e(error('nim')); ?>

                    </div>
                    <div class="form-group">
                        <label for="">Prodi</label>
                        <input type="text" name="jurusan" class="form-control" placeholder="Jurusan" required value="<?php echo e(old('jurusan')); ?>">
                        <?php echo e(error('jurusan')); ?>

                    </div>
                    <div class="form-group">
                        <label for="">Username</label>
                        <input type="text" name="username" class="form-control" placeholder="Username" required value="<?php echo e(old('username')); ?>">
                        <?php echo e(error('username')); ?>

                    </div>
                    <div class="form-group">
                        <label for="">Password</label>
                        <input type="password" name="password" class="form-control" placeholder="******" autocomplete="new-password" required>
                        <?php echo e(error('password')); ?>

                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn" data-dismiss="modal">
                        Batal
                    </button>
                    <button type="submit" class="btn btn-primary ms-1">
                        Simpan
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade text-left" id="ModalImport" tabindex="-1" role="dialog"
    aria-labelledby="myModalLabel1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="myModalLabel1">Import Data</h5>
                <button type="button" class="close rounded-pill" data-dismiss="modal"
                    aria-label="Close">
                    <i data-feather="x"></i>
                </button>
            </div>
            <form action="<?php echo e(base_url('koordinator-pkl/mahasiswa/import')); ?>" method="post" enctype="multipart/form-data">
                <div class="modal-body">
                    <div class="mb-3">
                        <h5><b>1.</b> Download template import data</h5>
                        <a href="<?php echo e(base_url('koordinator-pkl/mahasiswa/template_import')); ?>" class="btn bg-white border">Download Template</a>
                    </div>
                    <div class="mb-3">
                        <h5><b>2.</b> Upload file import data yang telah diisi </h5>
                        <div class="custom-file">
                            <input type="file" class="custom-file-input" name="file" id="fileimport" required>
                            <label class="custom-file-label" for="fileimport">Pilih File</label>
                        </div>
                        <small class="text-muted">
                            File harus berformat: .xlsx, dan maksimal ukuran file 8mb
                        </small>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn" data-dismiss="modal">
                        Batal
                    </button>
                    <button type="submit" class="btn btn-primary ms-1">
                        Import
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<?php echo show_modal(); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MyServer\www\client-projects\codeigniter\magang-app\app\views/koordinator-pkl/mahasiswa/create.blade.php ENDPATH**/ ?>