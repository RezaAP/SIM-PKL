<?php

class LaporanAkhirModel extends MY_Model {

    public $table = 'laporan_akhir';

}