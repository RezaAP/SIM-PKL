<?php

class DokumenPengajuanModel extends MY_Model {

    public $table = 'dokumen_pengajuan';

}