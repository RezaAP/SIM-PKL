<?php

class RoleModel extends MY_Model {

    public $table = 'role';

}